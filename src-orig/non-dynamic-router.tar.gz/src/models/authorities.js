
export default {
  namespace: 'authorities',
  state: {},
  reducers: {},
  effects: {},
  subscriptions: {},
};
